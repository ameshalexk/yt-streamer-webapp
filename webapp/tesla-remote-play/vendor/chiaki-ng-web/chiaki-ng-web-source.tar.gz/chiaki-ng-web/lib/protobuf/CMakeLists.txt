
if(NOT PROTOC OR NOT EXISTS "${PROTOC}")
	find_program(PROTOC protoc)
endif()
if(NOT PROTOC)
	message(FATAL_ERROR "Could not find protoc")
endif()

add_custom_command(OUTPUT "${CMAKE_CURRENT_BINARY_DIR}/takion.pb"
		COMMAND "${PROTOC}" "-o${CMAKE_CURRENT_BINARY_DIR}/takion.pb" "${CMAKE_CURRENT_SOURCE_DIR}/takion.proto" "-I${CMAKE_CURRENT_SOURCE_DIR}"
		MAIN_DEPENDENCY "${CMAKE_CURRENT_SOURCE_DIR}/takion.proto")

set(SOURCE_FILES "${CMAKE_CURRENT_BINARY_DIR}/takion.pb.c")
set(HEADER_FILES "${CMAKE_CURRENT_BINARY_DIR}/takion.pb.h")

# emcmake sets UNIX=TRUE even on a Windows host. cmake -E env with a
# colon-separated PATH then splits on spaces ("Program Files", etc.).
if(CMAKE_HOST_UNIX AND IS_ABSOLUTE "${PROTOC}")
	# make sure protoc is in PATH when invoking the generator below, which needs it.
	get_filename_component(PROTOC_PATH "${PROTOC}" DIRECTORY)
	set(GEN_PREFIX "${CMAKE_COMMAND}" -E env "PATH=${PROTOC_PATH}:$ENV{PATH}")
else()
	set(GEN_PREFIX "")
endif()

add_custom_command(OUTPUT ${SOURCE_FILES} ${HEADER_FILES}
		COMMAND ${GEN_PREFIX} "${PYTHON_EXECUTABLE}" "${NANOPB_GENERATOR_PY}" "${CMAKE_CURRENT_BINARY_DIR}/takion.pb"
		MAIN_DEPENDENCY "${CMAKE_CURRENT_BINARY_DIR}/takion.pb")

set(CHIAKI_LIB_PROTO_SOURCE_FILES "${SOURCE_FILES}" PARENT_SCOPE)
set(CHIAKI_LIB_PROTO_HEADER_FILES "${HEADER_FILES}" PARENT_SCOPE)
set(CHIAKI_LIB_PROTO_INCLUDE_DIR "${CMAKE_CURRENT_BINARY_DIR}" PARENT_SCOPE)

add_custom_target(chiaki-pb DEPENDS ${SOURCE_FILES} ${HEADER_FILES})
